<footer class="footer">
  <!-- <svg width="50px" height="50px" viewBox="0 0 50 50" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" >
      <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Desktop-Copy-6" transform="translate(-934.000000, -510.000000)">
              <g id="noun_344501_cc" transform="translate(934.000000, 510.000000)">
                <path d="M25,0 C11.1941964,0 0,11.1941964 0,25 C0,38.8058036 11.1941964,50 25,50 C38.8058036,50 50,38.8058036 50,25 C50,11.1941964 38.8058036,0 25,0 L25,0 Z" id="Shape" fill="#FF8076"></path>
              </g>
          </g>
      </g>
  </svg>
  <svg width="50px" height="50px" viewBox="0 0 50 50" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" >
      <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
          <g id="Desktop-Copy-6" transform="translate(-934.000000, -510.000000)">
              <g id="noun_344501_cc" transform="translate(934.000000, 510.000000)">
                <path d="M39.2857143,26.7857143 L26.7857143,26.7857143 L26.7857143,39.2857143 L23.2142857,39.2857143 L23.2142857,26.7857143 L10.7142857,26.7857143 L10.7142857,23.2142857 L23.2142857,23.2142857 L23.2142857,10.7142857 L26.7857143,10.7142857 L26.7857143,23.2142857 L39.2857143,23.2142857 L39.2857143,26.7857143 L39.2857143,26.7857143 Z" id="Path" fill="#FFFFFF"></path>
              </g>
          </g>
      </g>
  </svg> -->
</footer>
<?php wp_footer(); ?>
