<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0, minimal-ui">
  <title>Nikolas Payne Full Stack Designer</title>
  <?php wp_head(); ?>
</head>
